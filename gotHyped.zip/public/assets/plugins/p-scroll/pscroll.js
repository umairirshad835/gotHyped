(function($) {
    "use strict";

    const ps = new PerfectScrollbar('.app-sidebar', {
        useBothWheelAxes: true,
        suppressScrollX: true,
        suppressScrollY: false,
    });

    //P-scrolling
})(jQuery);