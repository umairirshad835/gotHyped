<div class="container">
    <div class="row align-items-center flex-row-reverse">
        <div class="col-md-12 col-sm-12 text-center">
            Copyright © 2022 <a href="javascript:void(0)">GotHyped</a>. Designed with <span
                class="fa fa-heart text-danger"></span> by <a href="javascript:void(0)"> MindTech (PVT) </a> All rights reserved.
        </div>
    </div>
</div><?php /**PATH D:\xampp\htdocs\Hyped\resources\views/layouts/components/footer.blade.php ENDPATH**/ ?>