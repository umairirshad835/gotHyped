

<?php $__env->startSection('content'); ?>

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title">Product Details</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- ROW-1 for Pending Auctions-->
        <?php if($product->auction_status == 0): ?>
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row row-sm">
                                <div class="col-xl-5 col-lg-12 col-md-12">
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <img src="<?php echo e(asset($product->image1)); ?>" alt="" style="width:100%;">
                                            <div class="clearfix carousel-slider">
                                                <div id="thumbcarousel" class="carousel slide" data-bs-interval="t">
                                                    <div class="carousel-inner">
                                                        <ul class="carousel-item active">

                                                            <?php if($product->image2): ?>
                                                            <li data-bs-target="#Slider" data-bs-slide-to="0" class="thumb active m-2"><img src="<?php echo e(asset($product->image2)); ?>" alt="" style="width:80%;height:60%;"></li>
                                                            <?php endif; ?>

                                                            <?php if($product->image3): ?>
                                                            <li data-bs-target="#Slider" data-bs-slide-to="0" class="thumb active m-2"><img src="<?php echo e(asset($product->image3)); ?>" alt="" style="width:80%;height:60%;"></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="details col-xl-7 col-lg-12 col-md-12 mt-4 mt-xl-0">
                                    <div class="mt-2 mb-4">
                                        <h3 class="mb-3 fw-semibold"> <?php echo e($product->name); ?> </h3>

                                        <h4 class="mt-4"><b> Description</b></h4>
                                        <p><?php echo e($product->description); ?></p>
                
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Actual Price :</span><span class="fw-bold text-success">$<?php echo e($product->actual_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Market Price :</span><span class="fw-bold text-success">$<?php echo e($product->market_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Price :</span><span class="fw-bold text-success">$<?php echo e($product->auction_price); ?></span></div>
                                        
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Sizes :</span>

                                        <?php $__currentLoopData = $sizenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="fw-bold text-success"><?php echo e($name->name); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Category :</span><span class="fw-bold text-success"><?php echo e($product->category->name); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Time :</span><span class="fw-bold text-success"><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($product->auction_time))->format('Y-m-d H:i:s A')); ?></span></div>

                                        <?php if($product->status == 1 ): ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">Active</span></div>
                                        <?php else: ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">In-Active</span></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- ROW-1 CLOSED -->


        <!-- ROW-2 for Active Auctions Auctions-->
        <?php if($product->auction_status == 1): ?>
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row row-sm">
                                <div class="col-xl-5 col-lg-12 col-md-12">
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <img src="<?php echo e(asset($product->image1)); ?>" alt="" style="width:100%;">
                                            <div class="clearfix carousel-slider">
                                                <div id="thumbcarousel" class="carousel slide" data-bs-interval="t">
                                                    <div class="carousel-inner">
                                                        <ul class="carousel-item active">

                                                            <?php if($product->image2): ?>
                                                            <li data-bs-target="#Slider" data-bs-slide-to="0" class="thumb active m-2"><img src="<?php echo e(asset($product->image2)); ?>" alt="" style="width:80%;height:60%;"></li>
                                                            <?php endif; ?>

                                                            <?php if($product->image3): ?>
                                                            <li data-bs-target="#Slider" data-bs-slide-to="0" class="thumb active m-2"><img src="<?php echo e(asset($product->image3)); ?>" alt="" style="width:80%;height:60%;"></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="details col-xl-7 col-lg-12 col-md-12 mt-4 mt-xl-0">
                                    <div class="mt-2 mb-4">
                                        <h3 class="mb-3 fw-semibold"> <?php echo e($product->name); ?> </h3>

                                        <h4 class="mt-4"><b> Description</b></h4>
                                        <p><?php echo e($product->description); ?></p>
                
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Actual Price :</span><span class="fw-bold text-success">$<?php echo e($product->actual_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Market Price :</span><span class="fw-bold text-success">$<?php echo e($product->market_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Price :</span><span class="fw-bold text-success">$<?php echo e($product->auction_price); ?></span></div>
                                        
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Sizes :</span>

                                        <?php $__currentLoopData = $sizenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="fw-bold text-success"><?php echo e($name->name); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Category :</span><span class="fw-bold text-success"><?php echo e($product->category->name); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Time :</span><span class="fw-bold text-success"><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($product->auction_time))->format('Y-m-d H:i:s A')); ?></span></div>

                                        <?php if($product->status == 1 ): ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">Active</span></div>
                                        <?php else: ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">In-Active</span></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- ROW-2 CLOSED -->


        <!-- ROW-3 for Completed Auctions-->
        <?php if($product->auction_status == 2): ?>
            <div class="row">
                <div class="col-xl-12">
                    <div class="card">
                        <div class="card-body">
                            <div class="row row-sm">
                                <div class="col-xl-5 col-lg-12 col-md-12">
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <img src="<?php echo e(asset($product->image1)); ?>" alt="" style="width:100%;">
                                            <div class="clearfix carousel-slider">
                                                <div id="thumbcarousel" class="carousel slide" data-bs-interval="t">
                                                    <div class="carousel-inner">
                                                        <ul class="carousel-item active">

                                                            <?php if($product->image2): ?>
                                                            <li data-bs-target="#Slider" data-bs-slide-to="0" class="thumb active m-2"><img src="<?php echo e(asset($product->image2)); ?>" alt="" style="width:80%;height:60%;"></li>
                                                            <?php endif; ?>

                                                            <?php if($product->image3): ?>
                                                            <li data-bs-target="#Slider" data-bs-slide-to="0" class="thumb active m-2"><img src="<?php echo e(asset($product->image3)); ?>" alt="" style="width:80%;height:60%;"></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="details col-xl-7 col-lg-12 col-md-12 mt-4 mt-xl-0">
                                    <div class="mt-2 mb-4">
                                        <h3 class="mb-3 fw-semibold"> <?php echo e($product->name); ?> </h3>

                                        <h4 class="mt-4"><b> Description</b></h4>
                                        <p><?php echo e($product->description); ?></p>
                
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Actual Price :</span><span class="fw-bold text-success">$<?php echo e($product->actual_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Market Price :</span><span class="fw-bold text-success">$<?php echo e($product->market_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Win Price :</span><span class="fw-bold text-success">$<?php echo e($product->auction_price); ?></span></div>
                                        
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Sizes :</span>

                                        <?php $__currentLoopData = $sizenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="fw-bold text-success"><?php echo e($name->name); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Category :</span><span class="fw-bold text-success"><?php echo e($product->category->name); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Time :</span><span class="fw-bold text-success"><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($product->auction_time))->format('Y-m-d H:i:s A')); ?></span></div>

                                        <?php if($product->status == 1 ): ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">Active</span></div>
                                        <?php else: ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">In-Active</span></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>


            <div class="row">
                <!-- Winner Details of Product or Auction -->
                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row row-sm">
                                <div class="col-xl-5 col-lg-12 col-md-12">
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <img src="https://via.placeholder.com/150" alt="" style="width:100%;">
                                        </div>
                                    </div>
                                </div>
                            
                                <div class="details col-xl-7 col-lg-12 col-md-12 mt-4 mt-xl-0">
                                    <div class="mt-2 mb-4">
                                    <h4 class="mt-4"><b> User</b></h4>
                                        <h3 class="mb-3 fw-semibold"> <?php echo e($winner->user->first()->name); ?> </h3>

                                        <h4 class="mt-4"><b> Description</b></h4>
                                        <p><?php echo e($product->description); ?></p>
                
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Actual Price :</span><span class="fw-bold text-success">$<?php echo e($product->actual_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Market Price :</span><span class="fw-bold text-success">$<?php echo e($product->market_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Win Price :</span><span class="fw-bold text-success">$<?php echo e($product->auction_price); ?></span></div>
                                        
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Sizes :</span>

                                        <?php $__currentLoopData = $sizenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="fw-bold text-success"><?php echo e($name->name); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Category :</span><span class="fw-bold text-success"><?php echo e($product->category->name); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Time :</span><span class="fw-bold text-success"><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($product->auction_time))->format('Y-m-d H:i:s A')); ?></span></div>

                                        <?php if($product->status == 1 ): ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">Active</span></div>
                                        <?php else: ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">In-Active</span></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>

                <!-- Bids Details of Product or Auction -->
                <div class="col-xl-6">
                    <div class="card">
                        <div class="card-body">
                            <div class="row row-sm">
                                <div class="col-xl-5 col-lg-12 col-md-12">
                                    <div class="row">
                                        <div class="col-xl-12">
                                            <img src="<?php echo e(asset($product->image1)); ?>" alt="" style="width:100%;">
                                            <div class="clearfix carousel-slider">
                                                <div id="thumbcarousel" class="carousel slide" data-bs-interval="t">
                                                    <div class="carousel-inner">
                                                        <ul class="carousel-item active">

                                                            <?php if($product->image2): ?>
                                                            <li data-bs-target="#Slider" data-bs-slide-to="0" class="thumb active m-2"><img src="<?php echo e(asset($product->image2)); ?>" alt="" style="width:80%;height:60%;"></li>
                                                            <?php endif; ?>

                                                            <?php if($product->image3): ?>
                                                            <li data-bs-target="#Slider" data-bs-slide-to="0" class="thumb active m-2"><img src="<?php echo e(asset($product->image3)); ?>" alt="" style="width:80%;height:60%;"></li>
                                                            <?php endif; ?>
                                                        </ul>
                                                    </div>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                                <div class="details col-xl-7 col-lg-12 col-md-12 mt-4 mt-xl-0">
                                    <div class="mt-2 mb-4">
                                        <h3 class="mb-3 fw-semibold"> <?php echo e($product->name); ?> </h3>

                                        <h4 class="mt-4"><b> Description</b></h4>
                                        <p><?php echo e($product->description); ?></p>
                
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Actual Price :</span><span class="fw-bold text-success">$<?php echo e($product->actual_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Market Price :</span><span class="fw-bold text-success">$<?php echo e($product->market_price); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Win Price :</span><span class="fw-bold text-success">$<?php echo e($product->auction_price); ?></span></div>
                                        
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Sizes :</span>

                                        <?php $__currentLoopData = $sizenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <span class="fw-bold text-success"><?php echo e($name->name); ?>, </span>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        
                                        </div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Category :</span><span class="fw-bold text-success"><?php echo e($product->category->name); ?></span></div>

                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Time :</span><span class="fw-bold text-success"><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($product->auction_time))->format('Y-m-d H:i:s A')); ?></span></div>

                                        <?php if($product->status == 1 ): ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">Active</span></div>
                                        <?php else: ?>
                                        <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">In-Active</span></div>
                                        <?php endif; ?>
                                    </div>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- ROW-3 CLOSED -->


    </div>
    <!-- CONTAINER CLOSED -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/Admin/product/view-product.blade.php ENDPATH**/ ?>