

<?php $__env->startSection('content'); ?>



<div class="side-app">

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title">Manage Product</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title">Product List</h3>
                        <a href="<?php echo e(route('addProduct')); ?>" class="btn" style="background-color:#5ba9dc;color:white;">Add Product</a>
                    </div>
                    <div class="card-body">
                            <div class="table-responsive">
                                <table class="table border text-nowrap text-md-nowrap mb-0">
                                    <thead style="background-color:#5ba9dc;">
                                        <tr>
                                            <th style="color:white;">#</th>
                                            <th style="color:white;">Name</th>
                                            <th style="color:white;">Category</th>
                                            <th style="color:white;">Auction Time</th>
                                            <th style="color:white;">Image</th>
                                            <th style="color:white;">Status</th>
                                            <th style="color:white;">Assign Size</th>
                                            <th style="color:white;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $productList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $product): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($product->name); ?></td>
                                            <td><?php echo e($product->category->name); ?></td>
                                            <td><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($product->auction_time))->format('Y-m-d H:i:s A')); ?></td>
                                            <td>
                                                <?php if(!empty($product->image1)): ?>
                                                    <img src="<?php echo e(asset($product->image1)); ?>" alt="" style="width:100px;height:80px">
                                                <?php else: ?>
                                                    <span>No Image Attached</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <form action="<?php echo e(route('changeProductStatus',$product->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="<?php echo e($product->status == 1 ? 0 : 1); ?>"/>

                                                    <?php if($product->status == 1): ?>
                                                        <button type="submit" class="btn btn-success">Active</button>
                                                    <?php else: ?>
                                                        <button type="submit" class="btn btn-danger">In-active</button>
                                                    <?php endif; ?>
                                                </form>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('assignSize',$product->id)); ?>" class="btn"  style="background-color:#5ba9dc; color:white">Assign Size</a>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('editProduct', $product->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>

                                                <a href="<?php echo e(route('previewProduct', $product->id)); ?>" target="_blank"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <br>
                            <?php echo e($productList->links()); ?>

                            <br>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
    </div>  

</div>    
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Hyped\resources\views/Admin/product/index.blade.php ENDPATH**/ ?>