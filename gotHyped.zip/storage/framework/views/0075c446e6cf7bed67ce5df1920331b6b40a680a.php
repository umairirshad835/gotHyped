

<?php $__env->startSection('content'); ?>



<div class="side-app">

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title">Winner Report</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title">Winner List</h3>
                    </div>
                    <div class="card-body">
                            <div class="table-responsive">
                                <table class="table border text-nowrap text-md-nowrap mb-0">
                                    <thead style="background-color:#5ba9dc;">
                                        <tr>
                                            <th style="color:white;">#</th>
                                            <th style="color:white;">Winner Name</th>
                                            <th style="color:white;">Winner Role</th>
                                            <th style="color:white;">Auction Name</th>
                                            <th style="color:white;">Image</th>
                                            <th style="color:white;">Winner Bid Used</th>
                                            <th style="color:white;">Total Bid Used</th>
                                            <th style="color:white;">Winning Price</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $winnerList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $winner): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($winner->user->first()->name); ?></td>
                                            <td>
                                            <?php if($winner->user->first()->roles == 'customer'): ?>
                                                    <span class="text-success"><?php echo e($winner->user->first()->roles); ?></span>
                                                <?php else: ?>
                                                    <span class="text-danger"><?php echo e($winner->user->first()->roles); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($winner->product->first()->name); ?></td>
                                            <td>
                                                <?php if(!empty($winner->product->first()->image1)): ?>
                                                    <img src="<?php echo e(asset($winner->product->first()->image1)); ?>" alt="" style="width:100px;height:80px">
                                                <?php else: ?>
                                                    <span>No Image Attached</span>
                                                <?php endif; ?>
                                            </td>
                                            <td><?php echo e($winner->WinnerBid->first()->bid_used); ?></td>
                                            <td><?php echo e($winner->total_bids); ?></td>
                                            <td>$ <?php echo e($winner->auction_close_price); ?></td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <br>
                            <?php echo e($winnerList->links()); ?>

                            <br>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
    </div>  

</div>    
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/Admin/user/winnerList.blade.php ENDPATH**/ ?>