

<?php $__env->startSection('content'); ?>

    <p>Congrats</p>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Hyped\resources\views/Admin/index.blade.php ENDPATH**/ ?>