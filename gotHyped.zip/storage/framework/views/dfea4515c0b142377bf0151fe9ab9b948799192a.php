
    <h1><?php echo e($data['code']); ?></h1>
   
    <p>Thank you</p>
<?php /**PATH D:\xampp\htdocs\Hyped\resources\views/emails/fotgot-OPTP.blade.php ENDPATH**/ ?>