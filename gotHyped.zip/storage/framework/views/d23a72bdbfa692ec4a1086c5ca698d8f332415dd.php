

<?php $__env->startSection('content'); ?>

<div class="side-app">

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title">Manage Category</h1>
        </div>
        <!-- PAGE-HEADER END -->
        
        <form method="POST" action="<?php echo e(route('updateCategory')); ?>" autocomplete="off" class="card">
            <?php echo csrf_field(); ?>
                <input type="hidden" name="category_id" id="category_id" value="<?php echo e($category->id); ?>">

            <div class="card-header" style="background-color:#5ba9dc;color:white;">
                <h3 class="card-title">Update Category</h3>
            </div>
            <div class="card-body">
                <div class="row">
                    <div class="col-xl-6 col-md-6">
                        <div class="form-group">
                            <label class="form-label">Name</label>
                            <input id="name" class="form-control <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> limitinput" value="<?php echo e($category->name); ?>" name="name" type="text" placeholder="Enter category name">
                                <?php $__errorArgs = ['name'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                    
                    <div class="col-xl-6 col-md-6">
                        <div class="form-group">
                            <label class="form-label">Status</label>
                            <select class="form-control form-select <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> is-invalid <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" data-placeholder="Choose one" name="status">
                                    <option label="Choose one"></option>
                                    <option value="1" <?php echo e($category->status == 1 ? 'selected' : ''); ?> >Active</option>
                                    <option value="0" <?php echo e($category->status == 0 ? 'selected' : ''); ?> >In-active</option>
                                </select>
                                <?php $__errorArgs = ['status'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($message); ?></strong>
                                    </span>
                                <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                    </div>
                </div>
                <div class="row" id="size">
                
                </div>
                <br>

                <button type="submit" class="btn py-1 px-4 mb-1" style="background-color:#5ba9dc;color:white;">Update Category</button>

            </div>
        </form>
    </div>
    <!-- CONTAINER CLOSED -->

</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>

<script src="https://code.jquery.com/jquery-3.6.0.min.js" integrity="sha256-/xUj+3OJU5yExlq6GSYGSHk7tPXikynS7ogEvDej/m4=" crossorigin="anonymous"></script>
    
    <script>

    $(document).ready(function() {
        
        var categoryID = $('#category_id').val();

        editSize(categoryID);

        function editSize(categoryID,productId)
        {
            $.ajax({
                url: '/get-category-size/'+categoryID,
                type: "GET",
                data : {"_token":"<?php echo e(csrf_token()); ?>"},
                dataType: "json",
                success:function(data)
                {
                    $('#size').empty();
                    $.each(data.sizes, function (index, el) {
                        var select_size = '';
                        $.each(data.category_size, function (key, val){
                                if(el['id'] == val['size_id'] && val['status'] == 1) {
                                    select_size = 'checked';
                            }
                        });
                        $('#size').append('<div class="col-xl-3 col-md-3"><label class="form-label"><input type="checkbox" name="size_id['+index+']" value="'+ el['id'] +'" '+select_size+'>' + el['name']+ ' </label></div>');
                    });
                }
            });
        }

        $('input.limitinput').on('keyup', function() {
            limitText(this, 50)
        });

        function limitText(field, maxChar){
            var ref = $(field),
                val = ref.val();
            if ( val.length >= maxChar ){
                ref.val(function() {
                    console.log(val.substr(0, maxChar))
                    return val.substr(0, maxChar);       
                });
            }
        }

    });
        
    </script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/Admin/category/update-category.blade.php ENDPATH**/ ?>