

<?php $__env->startSection('content'); ?>
    <style>
        .carousel-img {
            height:400px;
            width: 300px;
        }

        .list-img {
            height:100px;
        }
    </style>
    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title">Auction Report</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- ROW-3 for Completed Auctions-->
        <?php if($product->auction_status == 2): ?>
            <div class="row">
                <div class="card">
                    <div class="card-body">
                        <div class="row row-sm">
                            <div class="col-xl-5 col-lg-12 col-md-12">
                                <div class="row">
                                    <div class="col-xl-12">
                                        <div class="product-carousel">
                                            <div id="Slider" class="carousel slide border" data-bs-ride="false">
                                                <div class="carousel-inner">
                                                    <div class="carousel-item active"><img src="<?php echo e(asset($product->image1)); ?>" alt="img" class="img-fluid mx-auto d-block carousel-img">
                                                        <div class="text-center mt-5 mb-5 btn-list"></div>
                                                        </div>
                                                        <?php if($product->image2): ?>
                                                    <div class="carousel-item"> <img src="<?php echo e(asset($product->image2)); ?>" alt="img" class="img-fluid mx-auto d-block carousel-img">
                                                        <div class="text-center mb-5 mt-5 btn-list"></div>
                                                    </div>
                                                    <?php endif; ?>
                                                    <?php if($product->image3): ?>
                                                    <div class="carousel-item"> <img src="<?php echo e(asset($product->image3)); ?>" alt="img" class="img-fluid mx-auto d-block carousel-img">
                                                        <div class="text-center  mb-5 mt-5 btn-list"></div>
                                                    </div>
                                                    <?php endif; ?>
                                                </div>
                                            </div>
                                        </div>
                                        <div class="clearfix carousel-slider">
                                            <div id="thumbcarousel" class="carousel slide" data-bs-interval="t">
                                                <div class="carousel-inner">
                                                    <ul class="carousel-item active">
                                                        <li data-bs-target="#Slider" data-bs-slide-to="0" class="thumb active m-2"><img src="<?php echo e(asset($product->image1)); ?>" alt="img" class="list-img"></li>
                                                        <?php if($product->image2): ?>
                                                        <li data-bs-target="#Slider" data-bs-slide-to="1" class="thumb m-2"><img src="<?php echo e(asset($product->image2)); ?>" alt="img" class="list-img"></li>
                                                        <?php endif; ?>
                                                        <?php if($product->image3): ?>
                                                        <li data-bs-target="#Slider" data-bs-slide-to="2" class="thumb m-2"><img src="<?php echo e(asset($product->image3)); ?>" alt="img" class="list-img"></li>
                                                        <?php endif; ?>
                                                    </ul>
                                                </div>
                                            </div>
                                        </div>
                                    </div>
                                </div>
                            </div>
                            <div class="details col-xl-7 col-lg-12 col-md-12 mt-4 mt-xl-0">
                                <div class="mt-2 mb-4">
                                    <h3 class="mb-3 fw-semibold"> <?php echo e($product->name); ?> </h3>

                                    <h4 class="mt-4"><b> Description</b></h4>
                                    <p><?php echo e($product->description); ?></p>
            
                                    <div class=" mt-4 mb-5"><span class="fw-bold me-2">Actual Price :</span><span class="fw-bold text-success">$<?php echo e($product->actual_price); ?></span></div>

                                    <div class=" mt-4 mb-5"><span class="fw-bold me-2">Market Price :</span><span class="fw-bold text-success">$<?php echo e($product->market_price); ?></span></div>

                                    <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Price :</span><span class="fw-bold text-success">$<?php echo e($product->auction_price); ?></span></div>
                                    
                                    <div class=" mt-4 mb-5"><span class="fw-bold me-2">Sizes :</span>

                                    <?php $__currentLoopData = $sizenames; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $name): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <span class="fw-bold text-success"><?php echo e($name->name); ?><?php if( ! $loop->last): ?>,<?php endif; ?> </span>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    
                                    </div>

                                    <div class=" mt-4 mb-5"><span class="fw-bold me-2">Category :</span><span class="fw-bold text-success"><?php echo e($product->category->name ?? ''); ?></span></div>
                                    <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Time :</span><span class="fw-bold text-success"><?php echo e(\Carbon\Carbon::createFromTimestamp(strtotime($product->auction_time))->format('Y-m-d H:i:s A')); ?></span></div>

                                    <?php if($product->status == 1 ): ?>
                                    <div class=" mt-4 mb-5"><span class="fw-bold me-2">Product Status :</span><span class="fw-bold text-success">Approved</span></div>
                                    <?php else: ?>
                                    <div class=" mt-4 mb-5"><span class="fw-bold me-2">Status :</span><span class="fw-bold text-success">Un-Approved</span></div>
                                    <?php endif; ?>

                                    <?php if($product->auction_status == 2 ): ?>
                                    <div class=" mt-4 mb-5"><span class="fw-bold me-2">Auction Status :</span><span class="fw-bold text-success">Completed</span></div>
                                    <?php endif; ?>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="row">
                <!-- Winner Details of Product or Auction -->
                <div class="col-xl-12">
                    <div class="card" id="active-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h3 class="card-title"><?php echo e($product->name); ?> Preview</h3>
                        </div>
                        <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">#</th>
                                                <th style="color:white;">User</th>
                                                <th style="color:white;">Role</th>
                                                <th style="color:white;">winner</th>
                                                <th style="color:white;">Bid Used</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $completeview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $complete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(++$key); ?></td>
                                                    <td><?php echo e($complete->users->first()->name); ?></td>
                                                    <td><?php echo e($complete->users->first()->roles); ?></td>
                                                    <td>
                                                        <?php if($winner->user_id == $complete->user_id ): ?>
                                                            <span class="text-success"> &nbsp(Won)</span>
                                                        <?php else: ?>
                                                        <span class="text-danger"> &nbsp(Lost)</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($complete->bid_used); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th colspan="4"><h4>Total Bids</h4></th>
                                                <td><?php echo e($winner->total_bids); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <br>
                                <?php echo e($completeview->links()); ?>

                                <br>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- ROW-3 CLOSED -->

    </div>
    <!-- CONTAINER CLOSED -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/Admin/product/view-complete-product.blade.php ENDPATH**/ ?>