

<?php $__env->startSection('content'); ?>

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title">Auction Report</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- ROW-3 for Completed Auctions-->
        <?php if($product->auction_status == 2): ?>

            <div class="row">
                <!-- Winner Details of Product or Auction -->
                <div class="col-xl-12">
                    <div class="card" id="active-card">
                        <div class="card-header d-flex justify-content-between align-items-center">
                            <h3 class="card-title"><?php echo e($product->name); ?> Preview</h3>
                        </div>
                        <div class="card-body">
                                <div class="table-responsive">
                                    <table class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">#</th>
                                                <th style="color:white;">Product Name</th>
                                                <th style="color:white;">User</th>
                                                <th style="color:white;">Role</th>
                                                <th style="color:white;">winner</th>
                                                <th style="color:white;">Bid Used</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $completeview; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $complete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e(++$key); ?></td>
                                                    <td><?php echo e($complete->product->first()->name); ?></td>
                                                    <td><?php echo e($complete->users->first()->name); ?></td>
                                                    <td><?php echo e($complete->users->first()->roles); ?></td>
                                                    <td>
                                                        <?php if($winner->user_id == $complete->user_id ): ?>
                                                            <span class="text-success"> &nbsp(Won)</span>
                                                        <?php else: ?>
                                                        <span class="text-danger"> &nbsp(Lost)</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($complete->bid_used); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                            <tr>
                                                <th colspan="5"><h4>Total Bids</h4></th>
                                                <td><?php echo e($winner->total_bids); ?></td>
                                            </tr>
                                        </tbody>
                                    </table>
                                </div>
                                <br>
                                <?php echo e($completeview->links()); ?>

                                <br>
                        </div>
                    </div>
                </div>
            </div>
        <?php endif; ?>
        <!-- ROW-3 CLOSED -->

    </div>
    <!-- CONTAINER CLOSED -->

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/Admin/product/view-complete-product.blade.php ENDPATH**/ ?>