

<?php $__env->startSection('content'); ?>

<div class="side-app">

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title">Auction Report</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title">Completed Auctions</h3>
                    </div>
                    <div class="card-body">
                            <div class="table-responsive">
                                <table class="table border text-nowrap text-md-nowrap mb-0">
                                    <thead style="background-color:#5ba9dc;">
                                        <tr>
                                            <th style="color:white;">#</th>
                                            <th style="color:white;">Name</th>
                                            <th style="color:white;">Image</th>
                                            <th style="color:white;">Actual Price</th>
                                            <th style="color:white;">Market Price</th>
                                            <th style="color:white;">Winning Price</th>
                                            <th style="color:white;">Total Bids</th>
                                            <th style="color:white;">Winner</th>
                                            <th style="color:white;">Winner Role</th>
                                            <th style="color:white;">Action</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $completedAuctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $complete): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($complete->name); ?></td>
                                            <td>
                                                <?php if(!empty($complete->image1)): ?>
                                                    <img src="<?php echo e(asset($complete->image1)); ?>" alt="" style="width:100px;height:80px">
                                                <?php else: ?>
                                                    <span>No Image Attached</span>
                                                <?php endif; ?>
                                            </td>
                                            <td>$<?php echo e($complete->actual_price); ?></td>
                                            <td>$<?php echo e($complete->market_price); ?></td>
                                            <td>$ <?php echo e($complete->winner->first()->auction_close_price); ?></td>
                                            <td><?php echo e($complete->winner->first()->total_bids); ?></td>
                                            <td><?php echo e($complete->winner->first()->user->first()->username); ?></td>
                                            <td>
                                                <?php if($complete->winner->first()->user->first()->roles == 'customer'): ?>
                                                    <span class="text-success"><?php echo e($complete->winner->first()->user->first()->roles); ?></span>
                                                <?php else: ?>
                                                    <span class="text-danger"><?php echo e($complete->winner->first()->user->first()->roles); ?></span>
                                                <?php endif; ?>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('previewCompletedProduct', $complete->id)); ?>" target="_blank"><i class="fa fa-eye" aria-hidden="true"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <br>
                            <?php echo e($completedAuctions->links()); ?>

                            <br>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
    </div>  

</div>    
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/Admin/auctions/expire.blade.php ENDPATH**/ ?>