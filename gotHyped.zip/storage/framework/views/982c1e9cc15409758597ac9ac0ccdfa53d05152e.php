

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('custom-css'); ?>
   
<?php $__env->stopSection(); ?>


<div class="side-app">

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title"> <?php echo e($user->name); ?> Details</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <nav>
                            <div class="nav nav-tabs nav-fill border-bottom-0" id="nav-tab" role="tablist">

                                <a class="nav-item nav-link active " role="tab" aria-selected="true" href="#WalletBid" data-toggle="tab">
                                Wallet Bids
                                </a>
                                <a class="nav-item nav-link" href="#BidPurchase" role="tab" aria-selected="false" data-toggle="tab">
                                Bids Purchase
                                </a>
                                <a class="nav-item nav-link" href="#BidHistory" role="tab" aria-selected="false" data-toggle="tab">
                                Bids History
                                </a>
                                <a class="nav-item nav-link" href="#AuctionWon" role="tab" aria-selected="false" data-toggle="tab">
                                Auction Won
                                </a>
                                <a class="nav-item nav-link" href="#AuctionLost" role="tab" aria-selected="false" data-toggle="tab">
                                Auction Lost
                                </a>
                            </div>
                        </nav> 

                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <div class="tab-content">

                                <!-- WalletBid Tab content -->
                                <div class="tab-pane active" id="WalletBid">
                                    <table id="userTable" class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Current Bid</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr role="row">
                                                <?php if(!empty($user_bids->total_bids)): ?>
                                                    <td><?php echo e($user_bids->total_bids ?? ''); ?></td>
                                                <?php else: ?>
                                                    <tr><td class="text-center">No Data Found</td></tr>
                                                <?php endif; ?>
                                            </tr>
                                        </tbody>    
                                    </table>
                                </div>

                                <!-- BidPurchase Tab content -->
                                <div class="tab-pane" id="BidPurchase">
                                    <table id="userTable" class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Bid Purchase</th>
                                                <th style="color:white;">Purchase Price</th>
                                                <th style="color:white;">Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $purchased_bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr role="row">
                                                    <td><?php echo e($purchase->purchase_bids); ?></td>
                                                    <td>$<?php echo e($purchase->purchase_price); ?></td>
                                                    <td><?php echo e(date('d-M-Y H:i A', strtotime($purchase->created_at))); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr><td class="text-center">No Data Found</td></tr>
                                            <?php endif; ?>
                                        </tbody>    
                                    </table>
                                </div>

                                <!-- Bid History Tab content -->
                                <div class="tab-pane" id="BidHistory">
                                    <table id="userTable" class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Auction Name</th>
                                                <th style="color:white;">Image</th>
                                                <th style="color:white;">Bid Used</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr role="row">
                                                <?php $__empty_1 = true; $__currentLoopData = $bid_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr role="row">
                                                        <td><?php echo e($history->product->first()->name); ?></td>
                                                        <td> <?php if(!empty($history->product->first()->image1)): ?>
                                                                <img src="<?php echo e(asset($history->product->first()->image1)); ?>" alt="" style="width:100px;height:80px">
                                                            <?php else: ?>
                                                                <span>No Image Attached</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($history->bid_used); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr><td class="text-center">No Data Found</td></tr>
                                                <?php endif; ?>
                                            </tr>
                                        </tbody>    
                                    </table>
                                </div>

                                <!-- Auction Won Tab content -->
                                <div class="tab-pane" id="AuctionWon">
                                    <table id="userTable" class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Auction Name</th>
                                                <th style="color:white;">Auction Won Size's</th>
                                                <th style="color:white;">Image</th>
                                                <th style="color:white;">Market Value (if claimed)</th>
                                                <th style="color:white;">Address (if shipped)</th>
                                                <th style="color:white;">Bid Used</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                        <?php $__currentLoopData = $winner_auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $win): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <tr role="row">
                                                <td><?php echo e($win->winproduct->name); ?></td>
                                                <td><?php echo e($win->shippingAddress->size->name); ?></td>
                                                <td><img src="<?php echo e(asset($win->winproduct->image1)); ?>" alt="" style="width:100px;height:80px"></td>
                                                <td>
                                                    <?php if($win->market_value_status == 1): ?>
                                                        <?php echo e($win->winproduct->market_price); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td>
                                                    <?php if($win->get_product_status == 1): ?>
                                                        <?php echo e($win->shippingAddress->address->address); ?>

                                                    <?php endif; ?>
                                                </td>
                                                <td><?php echo e(App\Models\AuctionBidUsed::where('auction_id', $win->product_id)->where('user_id', $win->user_id)->first()->bid_used); ?></td>
                                            </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>    
                                    </table>
                                </div>

                                <!-- Auction Lost Tab content -->
                                <div class="tab-pane" id="AuctionLost">
                                    <table id="userTable" class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Auction Name</th>
                                                <th style="color:white;">Image</th>
                                                <th style="color:white;">Bids Lost</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $auction_lost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr role="row">
                                                    <td><?php echo e($lost->ProductLost->first()->name); ?></td>
                                                    <td> <?php if(!empty($lost->ProductLost->first()->image1)): ?>
                                                    <img src="<?php echo e(asset($lost->ProductLost->first()->image1)); ?>" alt="" style="width:100px;height:80px">
                                                    <?php else: ?>
                                                        <span>No Image Attached</span>
                                                    <?php endif; ?>
                                                </td>
                                                    <td><?php echo e($lost->lost_bids); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>    
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
    </div>  

</div>    
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/Admin/user/user_detail.blade.php ENDPATH**/ ?>