

<?php $__env->startSection('content'); ?>

<?php $__env->startSection('custom-css'); ?>
    <link rel="stylesheet" type="text/css" href="https://cdn.datatables.net/1.12.0/css/jquery.dataTables.css">
<?php $__env->stopSection(); ?>


<div class="side-app">

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title"> <?php echo e($user->name); ?> Details</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <nav>
                            <div class="nav nav-tabs nav-fill border-bottom-0" id="nav-tab" role="tablist">

                                <a class="nav-item nav-link active " role="tab" aria-selected="true" href="#WalletBid" data-toggle="tab">
                                Wallet Bids
                                </a>
                                <a class="nav-item nav-link" href="#BidPurchase" role="tab" aria-selected="false" data-toggle="tab">
                                Bids Purchase
                                </a>
                                <a class="nav-item nav-link" href="#BidHistory" role="tab" aria-selected="false" data-toggle="tab">
                                Bids History
                                </a>
                                <a class="nav-item nav-link" href="#AuctionWon" role="tab" aria-selected="false" data-toggle="tab">
                                Auction Won
                                </a>
                                <a class="nav-item nav-link" href="#AuctionLost" role="tab" aria-selected="false" data-toggle="tab">
                                Auction Lost
                                </a>
                            </div>
                        </nav> 

                    </div>

                    <div class="card-body">
                        <div class="table-responsive">
                            <div class="tab-content">

                                <!-- WalletBid Tab content -->
                                <div class="tab-pane active" id="WalletBid">
                                    <table id="userTable" class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Available Bids</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr role="row">
                                                <?php if(!empty($user_bids->total_bids)): ?>
                                                    <td><?php echo e($user_bids->total_bids ?? ''); ?></td>
                                                <?php else: ?>
                                                    <tr><td class="text-center">No Data Found</td></tr>
                                                <?php endif; ?>
                                            </tr>
                                        </tbody>    
                                    </table>
                                </div>

                                <!-- BidPurchase Tab content -->
                                <div class="tab-pane" id="BidPurchase">
                                    <table class="table border text-nowrap text-md-nowrap mb-0" id="purchase-bid-datatable">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Bid Purchase</th>
                                                <th style="color:white;">Purchase Price</th>
                                                <th style="color:white;">Date</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__empty_1 = true; $__currentLoopData = $purchased_bids; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $purchase): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                <tr role="row">
                                                    <td><?php echo e($purchase->purchase_bids ?? ''); ?></td>
                                                    <td>$<?php echo e($purchase->purchase_price ?? ''); ?></td>
                                                    <td><?php echo e(date('d-M-Y H:i A', strtotime($purchase->created_at))); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                <tr><td class="text-center">No Data Found</td></tr>
                                            <?php endif; ?>
                                        </tbody>    
                                    </table>
                                </div>

                                <!-- Bid History Tab content -->
                                <div class="tab-pane" id="BidHistory">
                                    <table id="bid-history-datatable" class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Auction Name</th>
                                                <th style="color:white;">Image</th>
                                                <th style="color:white;">Bid Used</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <tr role="row">
                                                <?php $__empty_1 = true; $__currentLoopData = $bid_history; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); $__empty_1 = false; ?>
                                                    <tr role="row">
                                                        <td><?php echo e($history->product->first()->name  ?? ''); ?></td>
                                                        <td> <?php if(!empty($history->product->first()->image1)): ?>
                                                                <img src="<?php echo e(asset($history->product->first()->image1  ?? '')); ?>" alt="" style="width:100px;height:80px">
                                                            <?php else: ?>
                                                                <span>No Image Attached</span>
                                                            <?php endif; ?>
                                                        </td>
                                                        <td><?php echo e($history->bid_used  ?? ''); ?></td>
                                                    </tr>
                                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); if ($__empty_1): ?>
                                                    <tr><td class="text-center">No Data Found</td></tr>
                                                <?php endif; ?>
                                            </tr>
                                        </tbody>    
                                    </table>
                                </div>

                                <!-- Auction Won Tab content -->
                                <div class="tab-pane" id="AuctionWon">
                                    <table id="auction-won-datatable" class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Auction Name</th>
                                                <th style="color:white;">Image</th>
                                                <th style="color:white;">Check Out Method</th>
                                                <th style="color:white;">Delivery Address</th>
                                                <th style="color:white;">Market Price</th>
                                                <th style="color:white;">Size</th>
                                                <th style="color:white;">Bid's Won</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $winner_auctions; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $win): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr>
                                                    <td><?php echo e($win->winproduct->name); ?></td>
                                                    <td>
                                                        <?php if(!empty($win->winproduct->image1)): ?>
                                                            <img src="<?php echo e(asset($win->winproduct->image1  ?? '')); ?>" alt="" style="width:100px;height:80px">
                                                        <?php else: ?>
                                                            <span>No Image Attached</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td>
                                                        <?php if($win->market_value_status == 1): ?>
                                                            <span>Market Price</span>
                                                        <?php else: ?>
                                                            <span>Delivery Address</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($win->shippingAddressNew->address->address  ?? ''); ?></td>
                                                    <td>
                                                        <?php if($win->market_value_status == 1): ?>
                                                            <span><?php echo e($win->winproduct->market_price  ?? ''); ?></span>
                                                        <?php else: ?>
                                                            <span>N/A</span>
                                                        <?php endif; ?>
                                                    </td>
                                                    <td><?php echo e($win->shippingAddressNew->size->name  ?? ''); ?></td>
                                                    <td><?php echo e(App\Models\AuctionBidUsed::where('user_id', $win->user_id)->where('auction_id', $win->product_id)->first()->bid_used  ?? ''); ?></td>
                                                </tr>
                                                
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>    
                                    </table>
                                </div>

                                <!-- Auction Lost Tab content -->
                                <div class="tab-pane" id="AuctionLost">
                                    <table id="auction-lost-datatable" class="table border text-nowrap text-md-nowrap mb-0">
                                        <thead style="background-color:#5ba9dc;">
                                            <tr>
                                                <th style="color:white;">Auction Name</th>
                                                <th style="color:white;">Image</th>
                                                <th style="color:white;">Bid's Lost</th>
                                            </tr>
                                        </thead>
                                        <tbody>
                                            <?php $__currentLoopData = $auction_lost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $lost): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                <tr role="row">
                                                    <td><?php echo e($lost->ProductLost->first()->name  ?? ''); ?></td>
                                                    <td> <?php if(!empty($lost->ProductLost->first()->image1  ?? '')): ?>
                                                    <img src="<?php echo e(asset($lost->ProductLost->first()->image1  ?? '')); ?>" alt="" style="width:100px;height:80px">
                                                    <?php else: ?>
                                                        <span>No Image Attached</span>
                                                    <?php endif; ?>
                                                </td>
                                                    <td><?php echo e($lost->lost_bids  ?? ''); ?></td>
                                                </tr>
                                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                        </tbody>    
                                    </table>
                                </div>

                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
    </div>  

</div>    
  

<?php $__env->stopSection(); ?>

<?php $__env->startSection('custom-js'); ?>

<script src="https://cdnjs.cloudflare.com/ajax/libs/jquery/3.3.1/jquery.min.js"></script>
<link href="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/css/bootstrap.min.css" rel="stylesheet" id="bootstrap-css">
<script src="//maxcdn.bootstrapcdn.com/bootstrap/4.1.1/js/bootstrap.min.js"></script>

<script type="text/javascript" charset="utf8" src="https://cdn.datatables.net/1.12.0/js/jquery.dataTables.js"></script>

<script>
$(document).ready( function () {
        $('#purchase-bid-datatable').DataTable();

    if (location.hash) {
        $("a[href='" + location.hash + "']").tab("show");
    }
    $(document.body).on("click", "a[data-toggle='tab']", function(event) {
        location.hash = this.getAttribute("href");
    });

    $(window).on("popstate", function() {
        var anchor = location.hash || $("a[data-toggle='tab']").first().attr("href");
        $("a[href='" + anchor + "']").tab("show");
    });

});

   

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/Admin/user/user_detail.blade.php ENDPATH**/ ?>