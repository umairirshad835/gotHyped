

<?php $__env->startSection('content'); ?>



<div class="side-app">

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title">Manage Product</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header" style="background-color:#5ba9dc;color:white;">
                        <h3 class="card-title">Assign Size's</h3>
                    </div>
                    
                    <div class="card-body">
                        <form method="POST" class="form-material" action="<?php echo e(route('saveProductSize')); ?>">
                            <div class="row">
                                <?php echo csrf_field(); ?>
                                <input type="hidden" name="product_id" value ="<?php echo e($product->id); ?>">
                                <?php $__currentLoopData = $sizes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <div class="col-xl-3 col-md-3">
                                        <label for=""> <input type="checkbox" name="size_id[<?php echo e($key); ?>]"  value="<?php echo e($size->id); ?>"> <?php echo e($size->name); ?></label>
                                    </div>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </div>
                            <br>
                            <button type="submit" class="btn waves-effect waves-light" style="background-color:#5ba9dc;color:white;">Save size</button>
                        </form>    
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
    </div>  

</div>    
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\Hyped\resources\views/Admin/product/assign-size.blade.php ENDPATH**/ ?>