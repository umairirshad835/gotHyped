

<?php $__env->startSection('content'); ?>



<div class="side-app">

    <!-- CONTAINER -->
    <div class="main-container container-fluid">

        <!-- PAGE-HEADER -->
        <div class="page-header">
            <h1 class="page-title">Manage Size</h1>
        </div>
        <!-- PAGE-HEADER END -->

        <!-- Row -->
        <div class="row">
            <div class="col-md-12">
                <div class="card">
                    <div class="card-header d-flex justify-content-between align-items-center">
                        <h3 class="card-title">Size List</h3>
                        <a href="<?php echo e(route('addSize')); ?>" class="btn" style="background-color:#5ba9dc;color:white;">Add Size</a>
                    </div>
                    <div class="card-body">
                            <div class="table-responsive">
                                <table class="table border text-nowrap text-md-nowrap mb-0">
                                    <thead style="background-color:#5ba9dc;">
                                        <tr>
                                            <th style="color:white;">#</th>
                                            <th style="color:white;">Name</th>
                                            <th style="color:white;">Status</th>
                                            <th style="color:white;">Actions</th>
                                        </tr>
                                    </thead>
                                    <tbody>
                                        <?php $__currentLoopData = $sizeList; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $size): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <tr>
                                            <td><?php echo e(++$key); ?></td>
                                            <td><?php echo e($size->name); ?></td>
                                            <td>
                                                <form action="<?php echo e(route('changeSizeStatus',$size->id)); ?>" method="POST">
                                                    <?php echo csrf_field(); ?>
                                                <input type="hidden" name="status" value="<?php echo e($size->status == 1 ? 0 : 1); ?>"/>
                                                    <?php if($size->status == 1): ?>
                                                        <button type="submit" class="btn btn-success">Active</button>
                                                    <?php else: ?>
                                                        <button type="submit" class="btn btn-danger">In-active</button>
                                                    <?php endif; ?>
                                                </form>
                                            </td>
                                            <td>
                                                <a href="<?php echo e(route('editSize', $size->id)); ?>"><i class="fa fa-pencil-square-o" aria-hidden="true"></i></a>
                                            </td>
                                        </tr>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </tbody>
                                </table>
                            </div>
                            <br>
                            <?php echo e($sizeList->links()); ?>

                            <br>
                    </div>
                </div>
            </div>
        </div>
        <!-- Row -->
    </div>  

</div>    
  

<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/Admin/size/index.blade.php ENDPATH**/ ?>