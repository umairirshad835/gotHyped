
<form action="<?php echo e(route('manageAuction')); ?>" method="post">
    <?php echo csrf_field(); ?>
<button type="submit">Manage Auction</button>
</form><?php /**PATH D:\xampp\htdocs\gotHyped\resources\views/auctionIndex.blade.php ENDPATH**/ ?>