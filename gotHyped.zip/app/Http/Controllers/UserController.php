<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;

use App\Models\User;
use App\Models\Winner;
use App\Models\UserBid;
use App\Models\BidPurchased;
use App\Models\AuctionBidUsed;
use App\Models\Loser;

class UserController extends Controller
{
    public function userList()
    {
        $userList = User::where('roles','customer')->paginate(25);

            return view('Admin.user.index',compact('userList'));
    }

    public function userdetail($id)
    {
        $user = User::find($id);

        $user_bids = UserBid::where('user_id',$id)->first();

        $purchased_bids = BidPurchased::where('user_id',$id)->get();

        $bid_history = AuctionBidUsed::with('product')->where('user_id',$id)->get();

        $winner_auctions = Winner::with(['winproduct'])->where('user_id',$id)->get();
        // dd($winner_auctions);

        $auction_won = AuctionBidUsed::where('user_id',$id)->whereIn('auction_id',$winner_auctions)->get();

        $auction_lost = Loser::with('ProductLost')->where('user_id',$id)->get();

        return view('Admin.user.user_detail',compact('user','user_bids','purchased_bids','bid_history','auction_won','auction_lost','winner_auctions'));
    }

    public function winnerList()
    {
        // $winnerList = Winner::select('id','user_id','product_id','auction_close_price')
        // ->whereHas('user', function($query){
        //     $query->select('name');
        // })
        // ->whereHas('product', function($query){
        //     $query->select('name','image1');
        // })
        // ->whereHas('WinnerBid', function($query){
        //     $query->select('user_id','bid_used');
        // })
        // ->paginate(25);

        $winnerList = Winner::with(['user','product','WinnerBid'])->paginate(25);
        //  dd($winnerList);

            return view('Admin.user.winnerList',compact('winnerList'));
    }
}
