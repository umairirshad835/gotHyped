
    <h1>{{ $data['code'] }}</h1>
   
    <p>Thank you</p>
