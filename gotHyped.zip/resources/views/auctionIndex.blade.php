
<form action="{{route('manageAuction')}}" method="post">
    @csrf
<button type="submit">Manage Auction</button>
</form>